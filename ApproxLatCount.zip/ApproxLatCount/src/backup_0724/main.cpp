#include <fstream>
#include <iostream>
#include <chrono>
#include <algorithm>
#include <vector>
#include <boost/math/distributions/normal.hpp>
#include <boost/unordered_map.hpp>
#include "unistd.h"
#include "polytope.h"
#include "glpk.h"

using namespace std;

typedef std::chrono::high_resolution_clock Clock;


struct cls_point {
	arma::vec p;
	double d;
	bool operator <(const cls_point &right) { return d < right.d; }
	bool operator >(const cls_point &right) { return d > right.d; }
};

polyvest::polytope* ReadFile(string fileName)
{

	polyvest::polytope *p;
	
	string line;

	ifstream fileReader(fileName);
	if (fileReader.is_open())
	{
		vector<double> arr;
	
		// parse the file and store all numbers
		while (getline(fileReader, line))
		{
			if (line.find('#') != string::npos)
				line.erase(line.find('#'));
				
			istringstream iss(line);
			
			double num;
			while ((iss >> num))
				arr.push_back(num);
		}
		fileReader.close();
		
		if (arr.size() < 2)
		{
			cout << "Error: Lack file content! Please Check Input File." << endl;
			exit(-1);
		}
			
		unsigned m = arr[0];
		unsigned n = arr[1] - 2;
		
		if (arr.size() != m * (n + 2) + 2)
		{
			cout << "Error: Incorrect number of elements! Please Check Input File" << endl;
			exit(-1);
		}
			
		p = new polyvest::polytope(m, n);
		
		unsigned index = 2;
		
		for (unsigned i = 0; i < n; i++)
		{
//			p->var_flag[i] = arr[index];
//			index++;
		}
		
		for (unsigned i = 0; i < m; i++) 
		{
			//P->vecOP[i] = (int)arr[index];	// 1: <=; 0: =;
			index++;		
		
			for (unsigned j = 0; j < n; j++)
			{
				p->matA(arr[index], i, j);
				index++;
			}
			
			p->vecb(arr[index], i);
			index++;
		}
		
		return p;
		
	}
	else
	{
		cout << "Error: " << fileName << " cannot open!" << endl;
		exit(-1);
	}
	
}

void print_help()
{
	cout << "Usage: ./IntSample [options ..] <infile>\n";
//	cout << "Options:\n";
//	cout << "  -h or -help\t\tPrint help.\n";
//	cout << "  -a or -approx\t\tEmploy approximate method (by default).\n";
//	cout << "    -seed=..\t\t  Set random seed.\n";
//	cout << "    -epsilon=..\t\t  Set accuracy parameter (by default epsilon = 0.1).\n";
//	cout << "    -delta=..\t\t  Set probability parameter (by default delta = 0.05).\n";
//	cout << "    -maxs=..\t\t  Set the max number of samples (by default maxs = 100000).\n";
//	cout << "    -vc or -vinci\t  Employ volume computation tool Vinci.\n";
//	cout << "    -pv or -polyvest\t  Employ volume estimation tool PolyVest.\n";
//	cout << "  -e or -exact\t\tEmploy exact method.\n";
}


int main(int argc, char **argv) 
{

	bool enableEllipsoid = true;
	
	auto timepoint = chrono::system_clock::now();
    auto fine = chrono::time_point_cast<chrono::milliseconds>(timepoint);

	srand((int)fine.time_since_epoch().count());

	double  threshold_upper = 0.6;
	double  threshold_lower = 0.4;
	double 	epsilon = 0.1;
	double 	delta = 0.05;
	boost::math::normal dist(0.0, 1.0);
	double	z = boost::math::quantile(dist, 1.0 - delta / 2);
	long unsigned maxs = 10000;

	if (argc < 2)
	{
		print_help();
		exit(-1);
	}

	string fileName = argv[argc - 1];

	for (int i = 1; i < argc; i++)
	{
		string arg_str = argv[i];
		int len = arg_str.length();

		if (arg_str[0] != '-' || len < 2) continue;
		
		if (arg_str == "-h" || arg_str == "-help")
		{
			print_help();
			exit(1);
		}
/*		
		if (arg_str == "-a" || arg_str == "-approx")
		{
			cout << "Enable approximate method and disable exact method.\n";
			approx_method = true;
			exact_method = false;
		} else
		{
			cout << "Unknown option \"" << arg_str << "\".\n";
			exit(-1);
		}
*/
	}
	
	
	auto t1 = Clock::now();
	
	polyvest::polytope *oP;
	
	oP = ReadFile(fileName);
	oP->Print();
	
	int m = oP->m;
	int n = oP->n;
	
	double COP = oP->ExactCount();
	cout << "CountOP " << COP << endl;
/*
	polyvest::polytope *newOP = new polyvest::polytope(2 * m, n);
	
	for (int i = 0; i < m; i++)
	{
		arma::vec object(n);
		for (int j = 0; j < n; j++)
		{
			newOP->matA(oP->matA(i, j), i, j);

			object(j) = oP->matA(i, j) * (1 + (rand() % 2 - 0.5) * 0.1);
			newOP->matA(object(j), m + i, j);
		}
		newOP->vecb(oP->vecb(i), i);		
		newOP->vecb(oP->Optimization(object), m + i);
	}
	
	delete oP;
	oP = newOP;
	oP->Print();
	m = oP->m;
	n = oP->n;
*/
	cout << "Read file \'" << fileName << "\' finished.\n";
	
	ofstream finalOut("results.txt", ios::app);
//	finalOut << fileName << ", ";
	finalOut.close();
	
	double RectSize = 1;
	double avgxr = 0;
	oP->GetBounds();
	for (int i = 0; i < n; i++)
	{
		RectSize *= round(oP->xmax[i]) - round(oP->xmin[i]) + 1;
		avgxr += oP->xmax[i] - oP->xmin[i];
	}
	avgxr = avgxr / n;
	cout << "x Avg Range:\t" << avgxr << endl;
	
	polyvest::polytope *Rect = new polyvest::polytope(2 * n, n);

	for (int i = 0; i < n; i++)
	{
		Rect->matA(1, i, i);
		Rect->vecb(round(oP->xmax[i]), i);
		Rect->matA(-1, i + n, i);
		Rect->vecb(-round(oP->xmin[i]), i + n);
	}

	polyvest::polytope *P = new polyvest::polytope(m + 2 * n, n);

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
			P->matA(oP->matA(i, j), i, j);
		
		arma::vec object(n);
		for (int j = 0; j < n; j++)
			object(j) = oP->matA(i, j);
		
		double upper = Rect->Optimization(object);
		if (upper < oP->vecb(i)) upper = oP->vecb(i);
		P->vecb(floor(upper), i);
	}
	
	for (int i = 0; i < n; i++)
	{
		P->matA(1, m + i, i);
		P->vecb(Rect->vecb(i), m + i);
		P->matA(-1, m + i + n, i);
		P->vecb(Rect->vecb(i + n), m + i + n);
	}
	
	P->Print();
	
	int big_loop_limit = 500;
	vector<arma::vec> plist;
//	int core_size = 0;
	long scount = 0;
	long wcount = 0;
	vector<double> ratiolist;
	double tmpPCount = RectSize;
	arma::vec point(n);
	
	do
	{

		long scount_local = 0;
		long wcount_local = 0;
	
		cout << "LOOP: " << big_loop_limit << endl;
		
		// copy from P then enlarge it
		polyvest::polytope *bigP = P->Clone();
		bigP->Enlarge(0.5);

		if (enableEllipsoid)
		{
			// copy from bigP then apply ellipsoid
			polyvest::polytope *bigQ = bigP->Clone();
			bigQ->AffineTrans();
			bigQ->PrepForWalk();
			if (plist.size() <= 0)
				bigQ->x.zeros();
			else 
				bigQ->x = bigQ->GetTransPoint(plist[rand() % plist.size()]);

			while (plist.size() < maxs)
			{				
				do 
				{
					// at least n steps
					for (int wi = 0; wi < n; wi++) 
						bigQ->Walk();
					point = bigQ->GetInvPoint(bigQ->x);

					for (int pi = 0; pi < n; pi++)
						point(pi) = round(point(pi));
					
					wcount++, wcount_local++;
					
				} while (!P->isInside(point));
		
				scount++, scount_local++;
			
				plist.push_back(point);

			}

			delete bigQ;
			
		} else 
		{
			
			bigP->PrepForWalk();
			if (plist.size() <= 0)
			{
				polyvest::polytope *bigQ = bigP->Clone();
				bigQ->AffineTrans();
				bigQ->x.zeros();
				bigP->x = bigQ->GetInvPoint(bigQ->x);
				delete bigQ;
			} else 
				bigP->x = plist[rand() % plist.size()];
			
			while (plist.size() < maxs)
			{
				do 
				{
					// at least n steps
					for (int wi = 0; wi < n; wi++)
						bigP->Walk();
					point = bigP->x;

					for (int pi = 0; pi < n; pi++)
						point(pi) = round(point(pi));
					
					wcount++, wcount_local++;
					
				} while (!P->isInside(point));
				
				scount++, scount_local++;
			
				plist.push_back(point);
			}			
			
		}
		
		delete bigP;
		
		cout << "SAMPLES / WALKS: " << scount_local << " / " << wcount_local << endl;
		
		long unsigned count = 0;
		double coef = 0.5;
		double coef_up = 1.1;
		double coef_lo = -0.1;
		polyvest::polytope *newP = P->Clone();
		
		for (long unsigned li = 0; li < plist.size(); li++)
			if (oP->isInside(plist[li])) count++;
		cout << "COUNT " << count << endl;
		
		if (count < maxs * threshold_lower)
		{
			cout << "COEF: ";
			int coef_loop_limit = 10;
			while (true)
			{
				cout << coef << " ";
				for (int i = 0; i < m; i++)
					newP->vecb(floor((P->vecb(i) - oP->vecb(i)) * coef + oP->vecb(i)), i);

				count = 0;
				for (long unsigned li = 0; li < plist.size(); li++)
					if (newP->isInside(plist[li])) count++;
				//cout << "COUNT " << count << endl;
				
				if (count > maxs * threshold_upper)
				{ 
					coef_up = coef;
					coef = (coef - coef_lo) / 2 + coef_lo;
				} else if (count < maxs * threshold_lower) 
				{
					coef_lo = coef;
					coef = coef_up - (coef_up - coef) / 2;
				} else break;
				
				if (coef_loop_limit <= 0)
				{
					while (true)
					{
						polyvest::polytope *tP = new polyvest::polytope(P->m + m, n);
						for (int i = 0; i < P->m; i++)
						{
							for (int j = 0; j < n; j++)
								tP->matA(P->matA(i, j), i, j);
							tP->vecb(P->vecb(i), i);
						}
						
						for (int i = 0; i < m; i++)
						{
							for (int j = 0; j < n; j++)
							{
								tP->matA(P->matA(i, j) * (1 + (rand() % 2 - 0.5) * 0.01), P->m + i, j);
							}
							tP->vecb(newP->vecb(i) * (1 + 0.5 * 0.01), P->m + i);							
						}
						
						delete newP;
						newP = tP;
							
						coef_loop_limit = 10;
						coef = 0.5;
						coef_lo = -0.1;
						coef_up = 1.1;
							
						break;
					}
				}
				
				coef_loop_limit--;
			}
			cout << endl;
			
			delete P;
			P = newP;
			
		} else big_loop_limit = 0;
		
		vector<arma::vec> tmplist;
		for (long unsigned li = 0; li < plist.size(); li++)
			if (P->isInside(plist[li])) tmplist.push_back(plist[li]);
		plist.resize(0);
		plist = tmplist;
		
//		cout << "R " << count << " " << maxs << endl;
		ratiolist.push_back((double)count / maxs);
//		double CountP;
//		if (looptimes == 0) 
//		{
//			CountP = oP->ExactCount();
//			oP->Print();
//		} else
//			CountP = P->ExactCount();
//		P->Print();
//		cout << "CountP: " << CountP << " " << tmpPCount << " " << CountP / tmpPCount << endl;
//		tmpPCount = CountP;

/*	
		if (midindex > plist.size() / 2 - 1)
		{
			boost::unordered_map<vector<double>, int> key_map;
			for (long unsigned pi = 0; pi < plist.size(); pi++)
			{
				vector<double> tmpvec;
				for (int idx = 0; idx < n; idx++) tmpvec.push_back(plist[pi].p(idx));
				std::pair<boost::unordered_map<vector<double>, int>::iterator, bool>
					p = key_map.insert(std::pair<vector<double>, int>(tmpvec, pi));
			}
			if (key_map.size() <= plist.size() / 5) 
			{
				looptimes = 0;
				core_size = key_map.size();
			}
			cout << "CORE_SIZE: " << key_map.size() << "/" << plist.size() << endl;
		}
*/
		big_loop_limit--;
		
	} while (big_loop_limit > 0);
	
	cout << "TOTAL SAMPLES / WALKS: " << scount << " / " << wcount << endl;
	
	cout << "Ratio: ";
	double ratio = 1;
	for (long unsigned ri = 0; ri < ratiolist.size(); ri++)
	{
		ratio *= ratiolist[ri];
		cout << ratiolist[ri] << " ";
	}
	cout << endl;
	cout << "i Est C(P):\t" << ratio << " " << RectSize << " " << ratio * RectSize << endl;

	double CountOP = oP->ExactCount();
	cout << "i Est C(P):\t" << ratio * RectSize  << " " << CountOP << " " << ratio * RectSize / CountOP << endl;	

	auto t2 = Clock::now();
	
//	finalOut.open("results.txt", ios::app);
//	finalOut << avgxr << ", " << 
//				(double)chrono::duration_cast<std::chrono::nanoseconds>(t2 - t1).count() / 1000000000 << endl;
//	finalOut.close();
	
	delete P;
	delete oP;
	
}





